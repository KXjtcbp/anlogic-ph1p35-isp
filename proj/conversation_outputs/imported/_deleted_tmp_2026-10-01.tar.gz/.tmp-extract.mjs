import fs from 'node:fs';
import zlib from 'node:zlib';

const src = process.argv[2];
const out = process.argv[3];
const buf = fs.readFileSync(src);
const starts = [];
for (let i = 0; i + 4 <= buf.length; i++) {
  if (buf[i] === 0x28 && buf[i + 1] === 0xb5 && buf[i + 2] === 0x2f && buf[i + 3] === 0xfd) starts.push(i);
}
const pieces = [];
let cursor = 0;
for (let k = 0; k < starts.length; k++) {
  const s = starts[k];
  if (s < cursor) continue;
  const e = k + 1 < starts.length ? starts[k + 1] : buf.length;
  try { pieces.push(zlib.zstdDecompressSync(buf.subarray(s, e))); cursor = e; } catch { /* skip */ }
}
const recs = [];
for (const l of Buffer.concat(pieces).toString('utf8').split('\n')) {
  if (!l.trim()) continue;
  try { recs.push(JSON.parse(l)); } catch { /* partial */ }
}
const textOf = (m) => (m?.content || []).map((c) => (typeof c === 'string' ? c : c.text || '[' + (c.type || '?') + ']')).join('\n');
const srcKind = (r) => r.data?.source?.kind ?? 'none';
const um = recs.filter((r) => r.type === 'user/message' && r.data);
const dump = [`user/message count: ${um.length}`];
for (const r of um) {
  const t = textOf(r.data).replace(/\s+/g, ' ');
  if (r.seq > 4000) dump.push(`seq=${r.seq} kind=${srcKind(r)} len=${t.length} :: ${t.slice(0, 240)}`);
}
fs.writeFileSync(out, dump.join('\n'), 'utf8');
console.log('done', um.length);
