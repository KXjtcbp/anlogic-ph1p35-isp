﻿import pymupdf
f = r"E:\FPGA\官方资料\12.SWUG\SWUG101_TangDynasty_Getting-Started_User_Guide_TD6.0.2_V1.0.pdf"
d = pymupdf.open(f)
out=[]
for i in range(12, 19):
    out.append(f"########## PAGE {i+1} ##########")
    out.append(d[i].get_text())
d.close()
open(r"E:\FPGA\_tmp_swug101_p13_19.txt","w",encoding="utf-8").write("\n".join(out))
print("ok")
