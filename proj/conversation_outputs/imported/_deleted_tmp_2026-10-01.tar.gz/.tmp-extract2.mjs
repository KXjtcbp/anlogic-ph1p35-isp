import fs from 'node:fs';
import zlib from 'node:zlib';

const src = process.argv[2];
const out = process.argv[3];
const buf = fs.readFileSync(src);
const starts = [];
for (let i = 0; i + 4 <= buf.length; i++) {
  if (buf[i] === 0x28 && buf[i + 1] === 0xb5 && buf[i + 2] === 0x2f && buf[i + 3] === 0xfd) starts.push(i);
}
const pieces = [];
let cursor = 0;
for (let k = 0; k < starts.length; k++) {
  const s = starts[k];
  if (s < cursor) continue;
  const e = k + 1 < starts.length ? starts[k + 1] : buf.length;
  try { pieces.push(zlib.zstdDecompressSync(buf.subarray(s, e))); cursor = e; } catch { /* skip */ }
}
const recs = [];
for (const l of Buffer.concat(pieces).toString('utf8').split('\n')) {
  if (!l.trim()) continue;
  try { recs.push(JSON.parse(l)); } catch { /* partial */ }
}
const textOf = (m) => (m?.content || []).map((c) => (typeof c === 'string' ? c : c.text || '[' + (c.type || '?') + ']')).join('\n');
const lines = ['total recs: ' + recs.length, 'types: ' + JSON.stringify(recs.reduce((a, r) => { a[r.type] = (a[r.type] || 0) + 1; return a; }, {}))];
// any record whose text content looks like a human instruction (not system reminder / plugin)
for (const r of recs) {
  const d = r.data;
  if (!d) continue;
  const kind = d?.source?.kind ?? (r.type.includes('user') ? 'user?' : '');
  if (kind !== 'user' && kind !== 'user?' && r.type !== 'user/message') continue;
  const t = textOf(d).replace(/\s+/g, ' ');
  if (!t) continue;
  if (t.startsWith('This is an automatically generated checkpoint')) continue;
  if (t.startsWith('<system-reminder>')) continue;
  if (t.startsWith('Current runtime context')) continue;
  lines.push(`seq=${r.seq} type=${r.type} kind=${JSON.stringify(d?.source ?? null)} len=${t.length} :: ${t}`);
}
fs.writeFileSync(out, lines.join('\n\n'), 'utf8');
console.log('done', recs.length);
