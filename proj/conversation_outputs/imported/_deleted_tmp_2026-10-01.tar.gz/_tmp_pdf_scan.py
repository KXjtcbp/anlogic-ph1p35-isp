﻿import pymupdf, re, sys
files = [
 r"E:\FPGA\官方资料\12.SWUG\SWUG101_TangDynasty_Getting-Started_User_Guide_TD6.0.2_V1.0.pdf",
 r"E:\FPGA\官方资料\8_FPGA学习资料\安路软件使用完整流程.pdf",
]
kw = re.compile(r"download|Download|program|Program|bit stream|bitstream|JTAG|SRAM|Flash|烧录|下载|固化|比特流")
for f in files:
    try:
        d = pymupdf.open(f)
    except Exception as e:
        print("ERR", f, e); continue
    print("="*20, f, "pages=", d.page_count)
    for i, pg in enumerate(d):
        t = pg.get_text()
        if "ownload" in t or "rogram" in t or "烧录" in t or "下载" in t:
            hits = [l.strip() for l in t.splitlines() if kw.search(l)]
            if hits:
                print(f"--- p{i+1} ---")
                for h in hits[:25]:
                    print("   ", h)
    d.close()
