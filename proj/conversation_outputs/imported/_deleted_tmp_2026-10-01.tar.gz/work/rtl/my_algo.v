//---------------------------------------------------------------------------
//  my_algo.v  --  自研图像处理模块（96bit 进 / 96bit 出）
//
//  插入位置：user_source/hdl_source/isp/isp_top.v 中替换 edge_detect_96 例化
//  数据格式：96 bit = 3 像素 × 32 bit，每像素 {8'h00, R[7:0], G[7:0], B[7:0]}
//            即 [31:24] 填充位/保留、[23:16] R、[15:8] G、[7:0] B
//
//  ★ 设计纪律（务必遵守）★
//  1. 端口名必须与 edge_detect_96.v 完全一致，一个字母都不能改。
//     注意 I_tready 是"输出"、O_tready 是"输入"，这是原例程的写法。
//  2. O_tdata / O_tlast / O_tuser / O_tvalid 必须与数据同拍。
//     数据路径插几级寄存器，这三个标记也必须跟着延几拍。
//  3. 本级只做"点运算"（不跨像素），不需要行缓存 → 时序压力最小。
//     ex3 底板 Setup WNS 只剩 +0.103 ns，这是本设计的硬约束。
//  4. 所有运算位宽必须显式声明，禁止隐式位宽转换。
//     每个通道最后必须 & 8'hFF 截回 8 bit，否则拼接宽度会爆掉。
//
//  OFF  : 直通（用于验证"接口接对了"）
//  MODE0: 原图
//  MODE1: 灰度（(R*77 + G*150 + B*29) >> 8，近似 BT.601 亮度）
//  MODE2: 伪彩热力图（灰度 → 蓝→青→绿→黄→红 查表）
//  MODE3: 阈值二值化（灰度 > THRESH 输出白，否则黑）——光照变化会失效，仅作演示
//
//---------------------------------------------------------------------------
module my_algo #(
    parameter integer OFF       = 0,          // 1 = 完全直通（调试用）
    parameter [7:0]   THRESH    = 8'd128,     // 二值化阈值
    parameter [1:0]   MODE_INIT = 2'd2        // 上电默认模式
)(
    input               I_clk    ,
    input               I_rst_n  ,
    input               I_tlast  ,
    input               I_tuser  ,
    input       [95:0]  I_tdata  ,
    input               I_tvalid ,
    output              I_tready ,
    output      [95:0]  O_tdata  ,
    output              O_tlast  ,
    output              O_tuser  ,
    output              O_tvalid ,
    input               O_tready
);

    //--------------------------------------------------------------
    // 无背压：与 edge_detect_96.v 完全一致
    //--------------------------------------------------------------
    assign I_tready = O_tready;

    //--------------------------------------------------------------
    // 输出打一拍（数据 + 三个标记同步延迟）
    //--------------------------------------------------------------
    reg  [95:0] O_tdata_r  ;
    reg         O_tlast_r  ;
    reg         O_tuser_r  ;
    reg         O_tvalid_r ;

    //--------------------------------------------------------------
    // 组合逻辑：对 3 个像素分别做点运算
    //--------------------------------------------------------------
    wire [23:0] px0 = I_tdata[23:0];
    wire [23:0] px1 = I_tdata[55:32];
    wire [23:0] px2 = I_tdata[87:64];

    // 亮度：R*77 + G*150 + B*29，右移 8 位
    function [7:0] f_luma;
        input [7:0] r;
        input [7:0] g;
        input [7:0] b;
        reg   [15:0] sum;
        begin
            sum = (r * 16'd77) + (g * 16'd150) + (b * 16'd29);
            f_luma = sum[15:8];
        end
    endfunction

    // 伪彩映射：蓝 → 青 → 绿 → 黄 → 红（五段线性）
    // 每一段的每个通道都显式取 8 bit，避免拼接宽度变成 30 bit
    function [23:0] f_heat;
        input [7:0] y;
        reg   [9:0] d;
        begin
            if(y < 8'd51) begin
                d = {2'b00, y};                       // 0..50
                f_heat = {8'h00, 8'h00, (d * 10'd5) & 10'h0FF};   // 蓝渐亮
            end
            else if(y < 8'd102) begin
                d = {2'b00, y} - 10'd51;              // 0..50
                f_heat = {8'h00, (d * 10'd5) & 10'h0FF, 8'hff};   // 蓝→青
            end
            else if(y < 8'd153) begin
                d = {2'b00, y} - 10'd102;
                f_heat = {8'h00, 8'hff, (10'd255 - d * 10'd5) & 10'h0FF}; // 青→绿
            end
            else if(y < 8'd204) begin
                d = {2'b00, y} - 10'd153;
                f_heat = {(d * 10'd5) & 10'h0FF, 8'hff, 8'h00};   // 绿→黄
            end
            else begin
                d = {2'b00, y} - 10'd204;
                f_heat = {8'hff, (10'd255 - d * 10'd5) & 10'h0FF, 8'h00}; // 黄→红
            end
        end
    endfunction

    function [23:0] f_pixel;
        input [23:0] p;
        input [1:0]  mode;
        reg   [7:0]  y;
        begin
            y = f_luma(p[23:16], p[15:8], p[7:0]);
            case(mode)
                2'd0: f_pixel = p;
                2'd1: f_pixel = {8'h00, y, y, y};
                2'd2: f_pixel = f_heat(y);
                2'd3: f_pixel = (y > THRESH) ? 24'hffffff : 24'h000000;
            endcase
        end
    endfunction

    wire [23:0] npx0 = f_pixel(px0, MODE_INIT);
    wire [23:0] npx1 = f_pixel(px1, MODE_INIT);
    wire [23:0] npx2 = f_pixel(px2, MODE_INIT);

    wire [95:0] new_data = {npx2, npx1, npx0};

    //--------------------------------------------------------------
    // 时序：与 edge_detect_96.v 相同的单级打拍
    //--------------------------------------------------------------
    always @(posedge I_clk or negedge I_rst_n) begin
        if(!I_rst_n) begin
            O_tdata_r  <= 96'd0;
            O_tlast_r  <= 1'b0;
            O_tuser_r  <= 1'b0;
            O_tvalid_r <= 1'b0;
        end
        else begin
            O_tdata_r  <= OFF ? I_tdata : new_data;
            O_tlast_r  <= I_tlast;
            O_tuser_r  <= I_tuser;
            O_tvalid_r <= I_tvalid;
        end
    end

    assign O_tdata  = O_tdata_r ;
    assign O_tlast  = O_tlast_r ;
    assign O_tuser  = O_tuser_r ;
    assign O_tvalid = O_tvalid_r;

endmodule
