﻿import pymupdf
files = [
 r"E:\FPGA\官方资料\1_安路工具和软件\新版TD驱动PH1P35使用方法\（必看）PH1P35烧写程序的使用方法.pdf",
 r"E:\FPGA\官方资料\1_安路工具和软件\新版TD驱动PH1P35使用方法\安路JTAG驱动安装_固件\al-link-ft刷pid教程_20240814.pdf",
]
out = []
for f in files:
    out.append("="*80)
    out.append("FILE: "+f)
    out.append("="*80)
    d = pymupdf.open(f)
    for i,p in enumerate(d):
        out.append(f"----- page {i+1}/{len(d)} -----")
        out.append(p.get_text())
txt = "\n".join(out)
open(r"E:\FPGA\_tmp_pdf_jtag.txt","w",encoding="utf-8").write(txt)
print("bytes:", len(txt.encode("utf-8")))
