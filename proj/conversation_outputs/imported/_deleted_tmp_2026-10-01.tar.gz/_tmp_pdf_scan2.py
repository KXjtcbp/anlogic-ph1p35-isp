﻿import pymupdf
f = r"E:\FPGA\官方资料\8_FPGA学习资料\安路软件使用完整流程.pdf"
d = pymupdf.open(f)
out = []
for i in range(18, 24):
    out.append(f"########## PAGE {i+1} ##########")
    out.append(d[i].get_text())
d.close()
open(r"E:\FPGA\_tmp_anlu_flow_p19_24.txt", "w", encoding="utf-8").write("\n".join(out))
print("written", sum(len(x) for x in out))
