﻿import fitz, sys
files = [
 r"E:\FPGA\官方资料\1_安路工具和软件\新版TD驱动PH1P35使用方法\（必看）PH1P35烧写程序的使用方法.pdf",
 r"E:\FPGA\官方资料\1_安路工具和软件\新版TD驱动PH1P35使用方法\安路JTAG驱动安装_固件\al-link-ft刷pid教程_20240814.pdf",
]
for f in files:
    print("="*90)
    print("FILE:", f)
    print("="*90)
    try:
        d = fitz.open(f)
        for i, p in enumerate(d):
            print(f"----- page {i+1}/{len(d)} -----")
            print(p.get_text())
    except Exception as e:
        print("ERROR:", e)
