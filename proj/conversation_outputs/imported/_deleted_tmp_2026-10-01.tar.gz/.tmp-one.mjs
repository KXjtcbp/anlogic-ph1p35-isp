import fs from 'node:fs';
import zlib from 'node:zlib';

const src = process.argv[2];
const out = process.argv[3];
const want = Number(process.argv[4]);
const buf = fs.readFileSync(src);
const starts = [];
for (let i = 0; i + 4 <= buf.length; i++) {
  if (buf[i] === 0x28 && buf[i + 1] === 0xb5 && buf[i + 2] === 0x2f && buf[i + 3] === 0xfd) starts.push(i);
}
const pieces = [];
let cursor = 0;
for (let k = 0; k < starts.length; k++) {
  const s = starts[k];
  if (s < cursor) continue;
  const e = k + 1 < starts.length ? starts[k + 1] : buf.length;
  try { pieces.push(zlib.zstdDecompressSync(buf.subarray(s, e))); cursor = e; } catch { /* skip */ }
}
const recs = [];
for (const l of Buffer.concat(pieces).toString('utf8').split('\n')) {
  if (!l.trim()) continue;
  try { recs.push(JSON.parse(l)); } catch { /* partial */ }
}
const textOf = (m) => (m?.content || []).map((c) => (typeof c === 'string' ? c : c.text || '[' + (c.type || '?') + ']')).join('\n');
const hit = recs.filter((r) => r.seq === want && r.type === 'user/message');
fs.writeFileSync(out, hit.map((r) => textOf(r.data)).join('\n---\n'), 'utf8');
console.log('found', hit.length);
